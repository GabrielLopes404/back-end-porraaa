# Backend - Lopes Designer

Backend Express.js para API REST.

## Deploy no Render

### Estrutura do Repositório GitHub

**IMPORTANTE:** Todos os arquivos devem estar NA RAIZ do repositório:

```
seu-repositorio/
├── package.json          ✅ RAIZ
├── render.yaml           ✅ RAIZ
├── .node-version         ✅ RAIZ
├── server/               ✅ RAIZ
├── data/                 ✅ RAIZ
└── shared/               ✅ RAIZ
```

**NÃO coloque dentro de pasta `src/` ou qualquer outra pasta!**

### Passo a Passo:

1. Extraia o ZIP
2. Faça upload de TODOS os arquivos para a RAIZ do repositório GitHub
3. Vá em [render.com](https://render.com)
4. Clique em "New +" → "Web Service"
5. Conecte seu repositório
6. O Render detecta automaticamente o `render.yaml`
7. Adicione a variável de ambiente:
   - `FRONTEND_URL` = URL do seu frontend no Vercel
8. Clique em "Create Web Service"

### Endpoints da API

```
GET /api/portfolio
GET /api/services  
GET /api/testimonials
GET /api/faqs
GET /api/before-after
```

### Variáveis de Ambiente

Adicione no Render:
```
FRONTEND_URL=https://seu-frontend.vercel.app
```

### Desenvolvimento Local

```bash
npm install
npm run dev
```

### Solução de Problemas

**Erro: "Could not read package.json"**
- Verifique que `package.json` está na RAIZ do repositório
- NÃO deve estar dentro de pasta `src/`

**Erro de CORS**
- Configure `FRONTEND_URL` no Render
- Inclua `https://` na URL

---

Desenvolvido com 💜 por Lopes Designer
